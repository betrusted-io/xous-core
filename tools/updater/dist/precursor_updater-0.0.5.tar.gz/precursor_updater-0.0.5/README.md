# Precursor Updater

This script can automatically update a Precursor device. Please run with `--help` to see
the available options. 

When the script is finished running, you will need to reset the device by pressing on the
switch inside the hole in the lower right hand side of the case. See https://ci.betrusted.io/i/reset.jpg
for an example of how to do this.
