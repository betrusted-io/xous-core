from .precursorupdater import main
