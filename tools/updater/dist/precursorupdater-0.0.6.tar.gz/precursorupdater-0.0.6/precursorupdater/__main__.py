import precursorupdater

precursorupdater.main()
